package proj;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

public class Data {
   
        private String name_patient;
        private String city_patient;
        private String age_patient;
        private String symptoms_patient;

        HashMap<String, LinkedList<String>> adjList = new HashMap<>();
        int count = 0;

        public Data(String name_patient)
        {
            this.name_patient =name_patient;
            this.city_patient ="";
            this.age_patient ="";
            this.symptoms_patient ="unknown";
        }

        public String getName_patient()
        {
            return name_patient;
        }

        public String getCity_patient() {
            return city_patient;
        }

        public String getAge_patient() {
            return age_patient;
        }

        public List<String> getFriends() {
            return adjList.get(this.name_patient);
        }

        public void setCity_patient(String city_patient) {
            this.city_patient = city_patient;
        }

        public void setAge_patient(String age_patient) {
            this.age_patient = age_patient;
        }

        public void addFriend(String friends) {
            LinkedList<String> nodes = adjList.get(name_patient);
            nodes.add(friends);
            adjList.put(name_patient, nodes);
        }

        public void removeFriend(String value)
        {
            if (adjList.containsKey(name_patient)) {
                LinkedList<String> nodes = adjList.get(name_patient);
                nodes.remove(value);
                adjList.put(name_patient, nodes);
            }
        }

        public String getSymptoms_patient() {
            return symptoms_patient;
        }

        public void setSymptoms_patient(String symptoms_patient) {
            this.symptoms_patient = symptoms_patient;
        }

        void addNode(String src){
            adjList.put(src, new LinkedList<>());
        }
        
    

}
