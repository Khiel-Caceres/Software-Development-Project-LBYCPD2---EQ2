package proj;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

import java.net.URL;
import java.util.ResourceBundle;

public class controllerr implements Initializable{

    @FXML
    public ListView<String> listview;

    @FXML
    public TextField text_field;

    @FXML
    public javafx.scene.control.Button button;


    @FXML
    private ObservableList<String> list;


    public void add(javafx.event.ActionEvent actionEvent) {
        list.add(text_field.getText());
        listview.setItems(list);
    }
    public void delete(javafx.event.ActionEvent actionEvent){
        list.remove(selectedIndex);
        text_field.clear();
    }

    private int selectedIndex = -1;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        list = FXCollections.observableArrayList();
        list.add("PATIENT");
        listview.setItems(list);
    }

    public void event(MouseEvent mouseEvent) {
        String selectedItem = listview.getSelectionModel().getSelectedItem().toString();
        selectedIndex = listview.getSelectionModel().getSelectedIndex();
        text_field.setText(selectedItem);
    }
}
