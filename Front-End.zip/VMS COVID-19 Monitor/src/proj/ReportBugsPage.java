package proj;
//NOT DONE
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class ReportBugsPage implements Initializable
{
    public Button goBack;
    public Button submitReport;

    public void close()
    {
        Stage stage = (Stage) submitReport.getScene().getWindow();
        stage.close();
    }

    public void clickGoBack() throws IOException
    {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("LoginPage.fxml"));
        Parent root1 = fxmlLoader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root1));
        stage.show();
        close();
    }

    //connects to a button to an admin page to see their reports
    public void clickSubmitReport()
    {

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}
