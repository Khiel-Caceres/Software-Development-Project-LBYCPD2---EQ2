package proj;
//DAGDAG KA NG GO BACK BUTTON
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class RegisterPage implements Initializable
{
    ObservableList list = FXCollections.observableArrayList();
    @FXML
    public TextField email;
    public PasswordField password;
    public TextField contactNumber;
    public Button signUp;
    public Button goBack;
    public ChoiceBox<String> userType;
    public CheckBox check;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        pickUserType();
    }

    //gets details and shows error message if none of the details are filled
    public void getUserInfo()
    {
        String email = this.email.getText();
        String pass = password.getText();
        String num = this.contactNumber.getText();
        if (!(email.isEmpty() || (pass.isBlank()) || (num.isBlank()) || (userType.isShowing()))) saveDetails(); //fix!!!!!!!!!!
        else
        {
            error1();
            setBlank();
        }
    }

    //objects for choiceBox
    public void pickUserType()
    {
        list.removeAll((list));
        String type1 = "PATIENT";
        String type2 = "NURSE";
        String type3 = "DOCTOR";
        String type4 = "ADMIN";
        list.addAll(type1, type2, type3, type4);
        userType.getItems().addAll(list);
    }

    //after the user picks a user type, it should be written in the word file so it can be scanned later (for now)
    public String getUserType(ChoiceBox<String> choice)
    {
        String type = choice.getValue();
        System.out.println("The user type chosen is " + type);
        return type;
    }

    //error if the text fields and choice box are left blank
    public void error1(){
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("ERROR!");
        window.setMinWidth(520);
        window.setMinHeight(150);
        Label message = new Label();
        message.setText("Please fill up all the details and/or select a user type");
        message.setFont(Font.font("Consolas", 16));
        message.setTextFill(Color.RED);
        VBox layout = new VBox(10);
        layout.getChildren().addAll(message);
        layout.setAlignment(Pos.CENTER);
        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();
    }

    //error if the user didn't check the check box
    public void error3()
    {
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("ERROR!");
        window.setMinWidth(520);
        window.setMinHeight(150);
        Label message = new Label();
        message.setText("You must agree with the terms and conditions to continue");
        message.setFont(Font.font("Consolas", 16));
        message.setTextFill(Color.RED);
        VBox layout = new VBox(10);
        layout.getChildren().addAll(message);
        layout.setAlignment(Pos.CENTER);
        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();
    }

    //message if registration went well
    public void success()
    {
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("SUCCESS!");
        window.setMinWidth(320);
        window.setMinHeight(150);
        Label message = new Label();
        message.setText("You are successfully registered");
        message.setFont(Font.font("Consolas", 16));
        message.setTextFill(Color.GREEN);
        VBox layout = new VBox(10);
        layout.getChildren().addAll(message);
        layout.setAlignment(Pos.CENTER);
        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();
    }

    public void setBlank()
    {
        email.setText("");
        password.setText("");
        contactNumber.setText("");
    }

    //saves the details to a txt file (for now)
    //try gawin yung idea ni khiel
    public void saveDetails(){
        String email = this.email.getText();
        String pass = password.getText();
        String num = this.contactNumber.getText();
        File myObj = new File(email);
        if (check.isSelected())
        {
            try
            {
                if (myObj.createNewFile())
                {
                    File file = new File(email);
                    FileWriter fr = new FileWriter(file, true);
                    BufferedWriter br = new BufferedWriter(fr);
                    success();
                    br.write(getUserType(userType));
                    br.newLine();
                    br.write(pass);
                    br.newLine();
                    br.write(num);
                    br.close();
                    fr.close();
                    FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("LoginPage.fxml"));
                    Parent root1 = fxmlLoader.load();
                    Stage stage = new Stage();
                    stage.setScene(new Scene(root1));
                    stage.show();
                    close();
                }
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
        }
        else error3();
    }

    //close the register page
    public void close()
    {
        Stage stage = (Stage) signUp.getScene().getWindow();
        stage.close();
    }

    public void clickGoBack() throws IOException
    {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("LoginPage.fxml"));
        Parent root1 = fxmlLoader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root1));
        stage.show();
        close();
    }
}

