package proj;
//MOSTLY DONE
import javafx.animation.FadeTransition;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;

public class LoginPage implements Initializable
{
    public Button overview;
    public Button prevention;
    public Button symptoms;
    public Button signIn;
    public Button signUp;
    public Button reportBugs;
    public TextField email;
    public PasswordField password;
    //public TextField userType;
    public AnchorPane ap;

    public void fadeInEffect()
    {
        FadeTransition fadeTransition = new FadeTransition();
        fadeTransition.setDuration(Duration.millis(1000));
        fadeTransition.setNode(ap);
        fadeTransition.setFromValue(0);
        fadeTransition.setToValue(1);
        fadeTransition.play();
    }

    public void clickOverview()
    {
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("COVID-19 OVERVIEW");
        window.setMinWidth(600);
        window.setMinHeight(320);
        Label message = new Label();
        message.setText("Coronavirus disease (COVID-19) is an infectious disease caused by a newly discovered coronavirus.\n" +
                "\n" +
                "Most people infected with the COVID-19 virus will experience mild to moderate respiratory illness and\n" +
                "recover without requiring special treatment. Older people, and those with underlying medical problems\n" +
                "like cardiovascular disease, diabetes, chronic respiratory disease, and cancer are more likely to\n" +
                "develop serious illness.\n" +
                "\n" +
                "The best way to prevent and slow down transmission is to be well informed about the COVID-19 virus,\n" +
                "the disease it causes and how it spreads. Protect yourself and others from infection by washing\n" +
                "your hands or using an alcohol based rub frequently and not touching your face.\n" +
                "\n" +
                "The COVID-19 virus spreads primarily through droplets of saliva or discharge from the nose when\n" +
                "an infected person coughs or sneezes, so it’s important that you also practice respiratory\n" +
                "etiquette (for example, by coughing into a flexed elbow).\n" +
                "\n\t\t\t\t\tSOURCE: www.who.int");
        message.setFont(Font.font("Consolas",13));
        message.setTextFill(Color.WHITE);
        message.setAlignment(Pos.TOP_LEFT);
        message.setTextAlignment(TextAlignment.JUSTIFY);
        VBox layout = new VBox(20);
        layout.setStyle("-fx-background-color: #272525");
        layout.getChildren().addAll(message);
        layout.setPadding(new Insets(20));
        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();
    }

    public void clickPrevention()
    {
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("COVID-19 PREVENTION");
        window.setMinWidth(600);
        window.setMinHeight(280);
        Label message = new Label();
        message.setText("To prevent infection and to slow transmission of COVID-19, do the following:\n" +
                "\n" +
                "-Wash your hands regularly with soap and water, or clean them with alcohol-based hand rub.\n" +
                "-Maintain at least 1 meter distance between you and people coughing or sneezing.\n" +
                "-Avoid touching your face.\n" +
                "-Cover your mouth and nose when coughing or sneezing.\n" +
                "-Stay home if you feel unwell.\n" +
                "-Refrain from smoking and other activities that weaken the lungs.\n" +
                "-Practice physical distancing by avoiding unnecessary travel and staying away from large groups of people.\n" +
                "\n\t\t\t\t\tSOURCE: www.who.int");
        message.setFont(Font.font("Consolas",13));
        message.setTextFill(Color.WHITE);
        message.setAlignment(Pos.TOP_LEFT);
        message.setTextAlignment(TextAlignment.JUSTIFY);
        VBox layout = new VBox(20);
        layout.setStyle("-fx-background-color: #272525");
        layout.getChildren().addAll(message);
        layout.setPadding(new Insets(20));
        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();
    }

    public void clickSymptoms()
    {
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("COVID-19 SYMPTOMS");
        window.setMinWidth(600);
        window.setMinHeight(400);
        Label message = new Label();
        message.setText("COVID-19 affects different people in different ways. Most infected people will develop mild to moderate illness and recover without hospitalization.\n" +
                "\n" +
                "MOST COMMON SYMPTOMS:\n" +
                "-Fever.\n" +
                "-Dry cough.\n" +
                "-Tiredness.\n" +
                "\n" +
                "LESS COMMON SYMPTOMS:\n" +
                "-Aches and pains.\n" +
                "-Sore throat.\n" +
                "-Diarrhea.\n" +
                "-Conjunctivitis.\n" +
                "-Headache.\n" +
                "-Loss of taste or smell.\n" +
                "-A rash on skin, or discoloration of fingers or toes.\n" +
                "\n" +
                "SERIOUS SYMPTOMS:\n" +
                "-Difficulty breathing or shortness of breath.\n" +
                "-Chest pain or pressure.\n" +
                "-Loss of speech or movement.\n" +
                "\n" +
                "Seek immediate medical attention if you have serious symptoms. Always call before visiting your doctor or health facility.\n" +
                "People with mild symptoms who are otherwise healthy should manage their symptoms at home. On average it takes 5–6 days\n" +
                "from when someone is infected with the virus for symptoms to show, however it can take up to 14 days.\n" +
                "\n\t\t\t\t\t\t\t\tSOURCE: www.who.int");
        message.setFont(Font.font("Consolas",13));
        message.setTextFill(Color.WHITE);
        message.setAlignment(Pos.TOP_LEFT);
        message.setTextAlignment(TextAlignment.JUSTIFY);
        VBox layout = new VBox(20);
        layout.setStyle("-fx-background-color: #272525");
        layout.getChildren().addAll(message);
        layout.setPadding(new Insets(20));
        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();
    }

    public void getInput()
    {
        String email = this.email.getText();
        String pass = password.getText();
        //String type = this.userType.getText();
        if (email.isEmpty() || (pass.isBlank()))
        {
            error1();
            setBlank();
        }
        else
        {
            try
            {
                verifyAccount();
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
        }
    }

    public void error1()
    {
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("ERROR!");
        window.setMinWidth(520);
        window.setMinHeight(150);
        Label message = new Label();
        message.setText("Enter your email, password and/or chosen user type");
        message.setFont(Font.font("Consolas", 16));
        message.setTextFill(Color.RED);
        VBox layout = new VBox(10);
        layout.getChildren().addAll(message);
        layout.setAlignment(Pos.CENTER);
        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();
    }

    public void error2()
    {
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("ERROR!");
        window.setMinWidth(280);
        window.setMinHeight(150);
        Label message = new Label();
        message.setText("Login has failed\n" +
                "Try again");
        message.setFont(Font.font("Consolas", 16));
        message.setTextFill(Color.RED);
        VBox layout = new VBox(10);
        layout.getChildren().addAll(message);
        layout.setAlignment(Pos.CENTER);
        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();
    }

    public void error3()
    {
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("ERROR!");
        window.setMinWidth(280);
        window.setMinHeight(150);
        Label message = new Label();
        message.setText("The account does not exist");
        message.setFont(Font.font("Consolas", 16));
        message.setTextFill(Color.RED);
        VBox layout = new VBox(10);
        layout.getChildren().addAll(message);
        layout.setAlignment(Pos.CENTER);
        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();
    }

    public void success()
    {
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("SUCCESS!");
        window.setMinWidth(320);
        window.setMinHeight(150);
        Label message = new Label();
        message.setText("You have successfully logged in");
        message.setFont(Font.font("Consolas", 16));
        message.setTextFill(Color.GREEN);
        VBox layout = new VBox(10);
        layout.getChildren().addAll(message);
        layout.setAlignment(Pos.CENTER);
        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();
    }

    public void fadeOutEffect()
    {
        FadeTransition fadeTransition = new FadeTransition();
        fadeTransition.setDuration(Duration.millis(7000));
        fadeTransition.setNode(ap);
        fadeTransition.setFromValue(1);
        fadeTransition.setToValue(0);
        fadeTransition.play();
    }

    public void setBlank()
    {
        email.setText("");
        password.setText("");
        //userType.setText("");
    }

    public void verifyAccount() throws IOException
    {
        String email = this.email.getText();
        String pass = password.getText();
        //String type = this.userType.getText();
        File myObj = new File(email);
        if (myObj.exists())
        {
            System.out.println("The account exists"); //checker only, remove later on
            try
            {
                Scanner myReader = new Scanner(myObj);
                while (myReader.hasNextLine())
                {
                    String data = myReader.nextLine();
                    System.out.println(data); //checker only, remove later on
                    if (data.equals(pass))
                    {
                        success();
                        fadeOutEffect();
                        setBlank();
                        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("PatientInterface.fxml"));
                        Parent root1 = fxmlLoader.load();
                        Stage stage = new Stage();
                        stage.setTitle("PATIENT");
                        stage.setScene(new Scene(root1));
                        stage.show();
                        close();
                    }
                    //plan is to have each user type have a separate text file, and
                    //there you can see all the user type (patient, nurse, doctor & admin) accounts
                        /*if (data.equals(type)) { //fix it so it goes to patient interface
                            success();
                            fadeOutEffect();
                            setBlank();
                            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("PatientInterface.fxml"));
                            Parent root1 = fxmlLoader.load();
                            Stage stage = new Stage();
                            stage.setTitle("PATIENT");
                            stage.setScene(new Scene(root1));
                            stage.show();
                            close();
                        }
                        else if (data.equals(type)) { //fix it so it goes to nurse interface
                            success();
                            fadeOutEffect();
                            setBlank();
                            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("NurseInterface.fxml"));
                            Parent root1 = fxmlLoader.load();
                            Stage stage = new Stage();
                            stage.setTitle("PATIENT");
                            stage.setScene(new Scene(root1));
                            stage.show();
                            close();
                        }
                        else if (data.equals(type)) { //fix it so it goes to doctor interface
                            success();
                            fadeOutEffect();
                            setBlank();
                            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("DoctorInterface.fxml"));
                            Parent root1 = fxmlLoader.load();
                            Stage stage = new Stage();
                            stage.setTitle("PATIENT");
                            stage.setScene(new Scene(root1));
                            stage.show();
                            close();
                        }
                        else if (data.equals(type)) { //fix it so it goes to admin interface
                            success();
                            fadeOutEffect();
                            setBlank();
                            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("AdminInterface.fxml"));
                            Parent root1 = fxmlLoader.load();
                            Stage stage = new Stage();
                            stage.setTitle("PATIENT");
                            stage.setScene(new Scene(root1));
                            stage.show();
                            close();
                        }
                    }*/
                }
                myReader.close();
            }
            catch (FileNotFoundException e)
            {
                error2();
                setBlank();
                e.printStackTrace();
            }
        }
        else
        {
            error3();
            setBlank();
        }
    }

    public void close()
    {
        Stage stage = (Stage) signIn.getScene().getWindow();
        stage.close();
    }

    public void goToRegisterPage() throws IOException
    {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/proj/RegisterPage.fxml"));
        Parent root1 = fxmlLoader.load();
        Stage stage = new Stage();
        stage.setTitle("REGISTER");
        stage.setScene(new Scene(root1));
        stage.show();
        close();
    }

    public void clickReportBugs()
    {
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setMinWidth(600);
        window.setMinHeight(400);
        reportBugs.setOnAction(e -> {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/proj/ReportBugsPage.fxml"));
            Parent root1 = null;
            try {
                root1 = fxmlLoader.load();
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
            Stage stage = new Stage();
            stage.setTitle("REPORT");
            assert root1 != null;
            stage.setScene(new Scene(root1));
            stage.show();
            close();
        });
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle)
    {
        ap.setOpacity(0);
        fadeInEffect();
    }
}
