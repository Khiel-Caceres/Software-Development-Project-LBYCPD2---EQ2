package proj;

import javafx.animation.FadeTransition;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.ResourceBundle;

public class LogoPage implements Initializable {
    public AnchorPane anchor;

    public void FadeOut(){
        FadeTransition fadeTransition = new FadeTransition();
        fadeTransition.setDuration(Duration.millis(5000));
        fadeTransition.setNode(anchor);
        fadeTransition.setFromValue(1);
        fadeTransition.setToValue(0);

        fadeTransition.setOnFinished(actionEvent -> {
            try {
                loadNext();
            } catch (IOException exception) {
                exception.printStackTrace();
            }
        });

        fadeTransition.play();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        FadeOut();
    }

    public void loadNext() throws IOException {
        try{
            Parent secondView;
            secondView =  FXMLLoader.load(Objects.requireNonNull(getClass().getResource("LoginPage.fxml")));
            Scene newScene = new Scene(secondView);
            Stage curstage  = (Stage) anchor.getScene().getWindow();
            curstage.setTitle("LOGIN");
            curstage.setMinWidth(1000);
            curstage.setMinHeight(700);
            curstage.setScene(newScene);
        } catch (IOException ex){
            ex.printStackTrace();
        }
    }
}
