package proj;
//NOT DONE
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.ResourceBundle;

public class PatientInterface implements Initializable
{
    ObservableList list = FXCollections.observableArrayList();
    public TextField nameTextField;
    public TextField cityTextField;
    public TextField ageTextField;
    public ChoiceBox<String> genderChoice;
    public ChoiceBox<String> symptomName;
    public Button showResults;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle)
    {
        pickSymptom();
        pickGender();
    }

    public void pickSymptom()
    {
        list.removeAll((list));
        //MOST COMMON
        String type1 = "FEVER";
        String type2 = "DRY COUGH";
        String type3 = "TIREDNESS";
        //LESS COMMON
        String type4 = "ACHES AND PAINS";
        String type5 = "SORE THROAT";
        String type6 = "DIARRHEA";
        String type7 = "CONJUNCTIVITIS";
        String type8 = "HEADACHE";
        String type9 = "LOSS OF TASTE/SMELL";
        String type10 = "RASH ON SKIN";
        String type11 = "FINGERS/TOES DISCOLORATION";
        //SERIOUS
        String type12 = "SHORTNESS OF BREATH";
        String type13 = "CHEST PAIN/PRESSURE";
        String type14 = "LOSS OF SPEECH/MOVEMENT";
        list.addAll(type1, type2, type3, type4, type5, type6, type7, type8, type9, type10, type11, type12, type13, type14);
        symptomName.getItems().addAll(list);
    }

    public void pickGender()
    {
        list.removeAll((list));
        String type1 = "MALE";
        String type2 = "FEMALE";
        list.addAll(type1, type2);
        genderChoice.getItems().addAll(list);
    }

    public void clickShowResults()
    {
        //put codes to make it show the results 
    }
}


