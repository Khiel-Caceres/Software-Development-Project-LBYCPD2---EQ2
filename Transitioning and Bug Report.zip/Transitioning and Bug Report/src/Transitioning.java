import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Properties;
import java.util.Scanner;

public class Transitioning {

    void menu(){
        Scanner input = new Scanner(System.in);

        int option=0;
        do{
            System.out.println("============MENU============");
            System.out.println("[1] Register");
            System.out.println("[2] Login");
            System.out.println("[3] Contact Tracing");
            System.out.println("[4] Exit");
            System.out.println(">>> ");
            option = input.nextInt();
            switch (option) {
                case 1:
                    register();
                    break;
                case 2:
                    login();
                    break;
                case 3:
                    contactTracing();
                    break;
                case 4:
                    System.out.println("Thank you.");
                    break;
                default:
                    System.out.println("Invalid Input");
            }
        } while (option!=3);
    }

    private void contactTracing() {
        String to = "lbycpd2@gmail.com"; // Send to receiver
        String from = "lbycpd2@gmail.com"; // from sender
        String password = "lbycpd2admin"; // password for sender

        Properties prop = new Properties();
        prop.put("mail.smtp.host", "smtp.gmail.com");
        prop.put("mail.smtp.port", "465");
        prop.put("mail.smtp.auth", "true");
        prop.put("mail.smtp.socketFactory.port", "465");
        prop.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");

        Session session = Session.getInstance(prop, new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(from, password);
            }
        });

        try {

            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(from));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
            message.setSubject("Contact Tracing Sheet");

            // Read contact tracing sheet
            String users = "";
            try {
                File myObj = new File("ContactTracing.txt");
                Scanner myReader = new Scanner(myObj);
                while (myReader.hasNextLine()) {
                    String data = myReader.nextLine();
                    users+=(data+"\n");
                }
                myReader.close();
            } catch (FileNotFoundException e) {
                System.out.println("An error occurred.");
                e.printStackTrace();
            }

            message.setText(users);

            Transport.send(message);

            System.out.println("Mail Sent...");

        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }

    void register() {
        Scanner input = new Scanner(System.in);

        System.out.println("Enter email adress: ");
        String email = input.nextLine();
        System.out.println("Enter password: ");
        String pass = input.nextLine();

        // User Type
        String type="";
        int option=0;
        do{
            System.out.println("============User Type============");
            System.out.println("[1] Patient");
            System.out.println("[2] Nurse");
            System.out.println("[3] Doctor");
            System.out.println("[4] Admin");
            System.out.println("[5] Exit");
            System.out.println(">>> ");
            option = input.nextInt();
            switch (option) {
                case 1:
                    type+="P";
                    break;
                case 2:
                    type+="N";
                    break;
                case 3:
                    type+="D";
                    break;
                case 4:
                    type+="A";
                    break;
                case 5:
                    System.out.println("Thank you.");
                    break;
                default:
                    System.out.println("Invalid Input");
            }
        } while (option!=5);

        // Create a File
        try {
            File myObj = new File("Accounts.txt");
            if (myObj.createNewFile()) {
                System.out.println(">>>>>File created: " + myObj.getName()+"<<<<<");
            } else {
                System.out.println(">>>>>File already exists.<<<<<");
            }
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        appendStrToFile(email+" "+pass+" "+type+"\n");

    }

    private void appendStrToFile(String str) {
        try {

            // Open given file in append mode.
            BufferedWriter out = new BufferedWriter(
                    new FileWriter("Accounts.txt", true));
            out.write(str);
            out.close();
        }
        catch (IOException e) {
            System.out.println("exception occoured" + e);
        }
    }

    private void appendStrToContact(String str) {
        try {

            // Open given file in append mode.
            BufferedWriter out = new BufferedWriter(
                    new FileWriter("ContactTracing.txt", true));
            out.write(str);
            out.close();
        }
        catch (IOException e) {
            System.out.println("exception occoured" + e);
        }
    }

    void login(){

        Scanner input = new Scanner(System.in);

        System.out.println("Enter email adress: ");
        String email = input.nextLine();
        System.out.println("Enter password: ");
        String pass = input.nextLine();

        boolean bool = false;
        try {
            File myObj = new File("Accounts.txt");
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                if(data.contains(email)&&(data.contains(pass))){
                    if(data.contains("P")){
                        System.out.println("Going to Patient Interface");
                    }
                    else if (data.contains("N")){
                        System.out.println("Going to Nurse Interface");
                    }
                    else if (data.contains("D")){
                        System.out.println("Going to Doctor Interface");
                    }
                    else{
                        System.out.println("Going to Admin Interface");
                    }
                    bool=true;
                    break;
                }
                else{
                    continue;
                }
            }
            if(!bool==true){
                System.out.println("Account not found.");
            }
            myReader.close();

            // Create a File
            try {
                File myObj1 = new File("ContactTracing.txt");
                if (myObj1.createNewFile()) {
                    System.out.println(">>>>>File created: " + myObj.getName()+"<<<<<");
                } else {
                    System.out.println(">>>>>File already exists.<<<<<");
                }
                LocalDate myObj2 = LocalDate.now();
                LocalTime myObj3 = LocalTime.now();
                appendStrToContact(email+" "+myObj2+" "+myObj3+"\n");

            } catch (IOException e) {
                System.out.println("An error occurred.");
                e.printStackTrace();
            }
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    public static void main(String[] args){
        Transitioning x = new Transitioning();
        x.menu();
    }
}
