package proj;

import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Modality;
import javafx.stage.Screen;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class SearchPatient
{
    public TextField name;
    public Button submit;
    public Button goBack;

    public void show(String dat)
    {
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("PATIENT SEARCH");
        Label message = new Label();
        message.setText(dat);
        message.setFont(Font.font("Consolas", 16));
        message.setTextFill(Color.BLACK);
        VBox layout = new VBox(20);
        layout.getChildren().addAll(message);
        layout.setStyle("-fx-background-color: #DAAAF8");
        layout.setPadding(new Insets(20, 20, 20, 20));
        layout.setAlignment(Pos.CENTER);
        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();

        Rectangle2D primScreenBounds = Screen.getPrimary().getVisualBounds();
        window.setX((primScreenBounds.getWidth() - window.getWidth()) / 2);
        window.setY((primScreenBounds.getHeight() - window.getHeight()) / 4);
    }

    public void setSearch()
    {
        String name = this.name.getText();
        boolean bool = false;
        try {
            File myObj = new File("PatientsDatabase.txt");
            Scanner fileReader = new Scanner(myObj);
            while (fileReader.hasNextLine())
            {
                String data = fileReader.nextLine();
                if(data.contains(name))
                {
                    show(data);
                    bool = true;
                    break;
                }
            }
            if(!bool)
            {
                error();
                this.name.setText("");
            }
            fileReader.close();
        }
        catch (FileNotFoundException e)
        {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    public void clickSubmit()
    {
        if (name.getText().isEmpty()) error();
        else
        {
            setSearch();
        }
        name.clear();
    }

    public void error()
    {
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("ERROR!");
        window.setMinWidth(320);
        window.setMinHeight(150);
        Label message = new Label();
        message.setText("Patient not found");
        message.setFont(Font.font("Consolas", 16));
        message.setTextFill(Color.RED);
        VBox layout = new VBox(10);
        layout.getChildren().addAll(message);
        layout.setAlignment(Pos.CENTER);
        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();
    }

    public void close()
    {
        Stage stage = (Stage) submit.getScene().getWindow();
        stage.close();
    }

    public void clickGoBack() throws IOException
    {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("NurseInterface.fxml"));
        Parent root1 = fxmlLoader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root1));
        stage.setTitle("NURSE");
        stage.show();
        close();
    }
}
