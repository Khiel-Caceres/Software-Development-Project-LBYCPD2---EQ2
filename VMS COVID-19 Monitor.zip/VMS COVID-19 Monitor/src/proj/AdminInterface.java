package proj;
//NOT DONE

import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Modality;
import javafx.stage.Screen;
import javafx.stage.Stage;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.Scanner;

public class AdminInterface
{
    public Button contactTracing;
    public Button displayDatabase;
    public Button goBack;

    public void clickContactTracing()
    {
        String to = "lbycpd2@gmail.com"; // Send to receiver
        String from = "lbycpd2@gmail.com"; // from sender
        String password = "lbycpd2admin"; // password for sender

        Properties prop = new Properties();
        prop.put("mail.smtp.host", "smtp.gmail.com");
        prop.put("mail.smtp.port", "465");
        prop.put("mail.smtp.auth", "true");
        prop.put("mail.smtp.socketFactory.port", "465");
        prop.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");

        Session session = Session.getInstance(prop, new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(from, password);
            }
        });

        try {

            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(from));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
            message.setSubject("Contact Tracing Sheet");

            // Read contact tracing sheet
            StringBuilder users = new StringBuilder();
            try {
                File myObj = new File("ContactTracing.txt");
                Scanner myReader = new Scanner(myObj);
                while (myReader.hasNextLine()) {
                    String data = myReader.nextLine();
                    users.append(data).append("\n");
                }
                myReader.close();
            } catch (FileNotFoundException e) {
                System.out.println("An error occurred.");
                e.printStackTrace();
            }
            message.setText(users.toString());
            Transport.send(message);
            success();

        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }

    public void clickDisplayDatabase()
    {
        try
        {
            File myObj = new File("PatientsDatabase.txt");
            Scanner fileReader = new Scanner(myObj);
            StringBuilder database = new StringBuilder();
            while (fileReader.hasNextLine())
            {
                String data = fileReader.nextLine();
                database.append(data).append("\n");
            }
            fileReader.close();
            showDatabase(database.toString());
        }

        catch (FileNotFoundException e)
        {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    public void showDatabase(String dat)
    {
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("PATIENT DATABASE");
        Label message = new Label();
        message.setText(dat);
        message.setFont(Font.font("Consolas", 16));
        message.setTextFill(Color.BLACK);
        VBox layout = new VBox(20);
        layout.getChildren().addAll(message);
        layout.setStyle("-fx-background-color: #C0FCC3");
        layout.setPadding(new Insets(20, 20, 20, 20));
        layout.setAlignment(Pos.CENTER);
        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();

        Rectangle2D primScreenBounds = Screen.getPrimary().getVisualBounds();
        window.setX((primScreenBounds.getWidth() - window.getWidth()) / 2);
        window.setY((primScreenBounds.getHeight() - window.getHeight()) / 4);
    }

    public void success()
    {
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("SUCCESS!");
        window.setMinWidth(500);
        window.setMinHeight(150);
        Label message = new Label();
        message.setText("Contact tracing sheet has been sent to Gmail");
        message.setFont(Font.font("Consolas", 16));
        message.setTextFill(Color.GREEN);
        VBox layout = new VBox(10);
        layout.getChildren().addAll(message);
        layout.setAlignment(Pos.CENTER);
        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();
    }

    public void close()
    {
        Stage stage = (Stage) contactTracing.getScene().getWindow();
        stage.close();
    }

    public void clickGoBack() throws IOException
    {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("LoginPage.fxml"));
        Parent root1 = fxmlLoader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root1));
        stage.setTitle("VMS: COVID-19 Monitor");
        stage.show();
        close();
    }
}
