package proj;

import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.*;
import java.util.Scanner;

public class DeletePatient
{
    public TextField name;
    public Button submit;
    public Button goBack;

    public void setDelete()
    {
        String name = this.name.getText();
        StringBuilder database = new StringBuilder();
        // Read database
        try
        {
            File myObj = new File("PatientsDatabase.txt");
            Scanner fileReader = new Scanner(myObj);
            while (fileReader.hasNextLine())
            {
                String data = fileReader.nextLine();
                if(!(data.contains(name))) database.append(data).append("\n");
            }
            fileReader.close();
        }
        catch (FileNotFoundException e)
        {
            error();
            e.printStackTrace();
        }

        // Delete previous database
        File myObj = new File("PatientsDatabase.txt");
        myObj.delete();


        // Create a new database
        try
        {
            File myObj1 = new File("PatientsDatabase.txt");
            myObj1.createNewFile();
        }
        catch (IOException e)
        {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        appendStrToPatientDB(database.toString());
    }

    public void clickSubmit()
    {
        if (name.getText().isEmpty()) error();
        else
        {
            setDelete();
            success();
        }
        name.clear();
    }

    private void appendStrToPatientDB(String str)
    {
        try
        {
            // Open given file in append mode.
            BufferedWriter out = new BufferedWriter(new FileWriter("PatientsDatabase.txt", true));
            out.write(str);
            out.close();
        }
        catch (IOException e)
        {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    public void error()
    {
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("ERROR!");
        window.setMinWidth(320);
        window.setMinHeight(150);
        Label message = new Label();
        message.setText("Patient not found");
        message.setFont(Font.font("Consolas", 16));
        message.setTextFill(Color.RED);
        VBox layout = new VBox(10);
        layout.getChildren().addAll(message);
        layout.setAlignment(Pos.CENTER);
        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();
    }

    public void success()
    {
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("SUCCESS!");
        window.setMinWidth(400);
        window.setMinHeight(150);
        Label message = new Label();
        message.setText("Patient has been deleted");
        message.setFont(Font.font("Consolas", 16));
        message.setTextFill(Color.GREEN);
        VBox layout = new VBox(10);
        layout.getChildren().addAll(message);
        layout.setAlignment(Pos.CENTER);
        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();
    }

    public void close()
    {
        Stage stage = (Stage) submit.getScene().getWindow();
        stage.close();
    }

    public void clickGoBack() throws IOException
    {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("NurseInterface.fxml"));
        Parent root1 = fxmlLoader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root1));
        stage.setTitle("NURSE");
        stage.show();
        close();
    }
}
