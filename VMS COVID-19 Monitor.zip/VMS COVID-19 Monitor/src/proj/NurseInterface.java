package proj;
//NOT DONE
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class NurseInterface
{
    public Button add;
    public Button del;
    public Button edit;
    public Button search;
    public Button goBack;

    public void clickAddPatient() throws IOException
    {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("AddPatient.fxml"));
        Parent root1 = fxmlLoader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root1));
        stage.setTitle("ADD PATIENT");
        stage.show();
        close();
    }

    public void clickDeletePatient() throws IOException
    {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("DeletePatient.fxml"));
        Parent root1 = fxmlLoader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root1));
        stage.setTitle("DELETE PATIENT");
        stage.show();
        close();
    }

    public void clickEditPatient() throws IOException
    {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("EditPatient.fxml"));
        Parent root1 = fxmlLoader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root1));
        stage.setTitle("EDIT PATIENT");
        stage.show();
        close();
    }

    public void clickSearchPatient() throws IOException
    {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("SearchPatient.fxml"));
        Parent root1 = fxmlLoader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root1));
        stage.setTitle("SEARCH PATIENT");
        stage.show();
        close();
    }

    public void close()
    {
        Stage stage = (Stage) add.getScene().getWindow();
        stage.close();
    }

    public void clickGoBack() throws IOException
    {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("LoginPage.fxml"));
        Parent root1 = fxmlLoader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root1));
        stage.setTitle("VMS: COVID-19 Monitor");
        stage.show();
        close();
    }
}
