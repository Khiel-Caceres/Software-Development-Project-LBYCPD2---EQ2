package proj;
//NOT DONE
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Modality;
import javafx.stage.Screen;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class DoctorInterface
{
    public Button showAll;
    public Button goBack;
    public TextField city;

    public void displayAllPatients()
    {
        String city = this.city.getText();
        StringBuilder list = new StringBuilder();
        boolean bool = false;
        try
        {
            File myObj = new File("PatientsDatabase.txt");
            Scanner fileReader = new Scanner(myObj);
            while (fileReader.hasNextLine())
            {
                String data = fileReader.nextLine();
                if(data.contains(city))
                {
                    list.append(data).append("\n");
                    bool = true;
                }
            }
            showPatients(list.toString());
            if (!bool)
            {
                error2();
                this.city.setText("");
            }
            fileReader.close();
        }
        catch (FileNotFoundException e)
        {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    public void clickShowAllPatients()
    {
        if (!(city.getText().isEmpty())) displayAllPatients();
        else
        {
            error1();
        }
        city.clear();
    }

    public void showPatients(String dat)
    {
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("PATIENTS ACCORDING TO CITY");
        Label message = new Label();
        message.setText(dat);
        message.setFont(Font.font("Consolas", 16));
        message.setTextFill(Color.BLACK);
        VBox layout = new VBox(20);
        layout.getChildren().addAll(message);
        layout.setStyle("-fx-background-color: #B0D7F3");
        layout.setPadding(new Insets(20, 20, 20, 20));
        layout.setAlignment(Pos.CENTER);
        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();

        Rectangle2D primScreenBounds = Screen.getPrimary().getVisualBounds();
        window.setX((primScreenBounds.getWidth() - window.getWidth()) / 2);
        window.setY((primScreenBounds.getHeight() - window.getHeight()) / 4);
    }

    public void error1()
    {
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("ERROR!");
        window.setMinWidth(700);
        window.setMinHeight(150);
        Label message = new Label();
        message.setText("Please fill up the city detail needed before showing all of the patients");
        message.setFont(Font.font("Consolas", 16));
        message.setTextFill(Color.RED);
        VBox layout = new VBox(10);
        layout.getChildren().addAll(message);
        layout.setAlignment(Pos.CENTER);
        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();
    }

    //small bug here; debug later
    public void error2()
    {
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("ERROR!");
        window.setMinWidth(320);
        window.setMinHeight(150);
        Label message = new Label();
        message.setText("Patient not found");
        message.setFont(Font.font("Consolas", 16));
        message.setTextFill(Color.RED);
        VBox layout = new VBox(10);
        layout.getChildren().addAll(message);
        layout.setAlignment(Pos.CENTER);
        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();
    }

    public void close()
    {
        Stage stage = (Stage) showAll.getScene().getWindow();
        stage.close();
    }

    public void clickGoBack() throws IOException
    {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("LoginPage.fxml"));
        Parent root1 = fxmlLoader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root1));
        stage.setTitle("VMS: COVID-19 Monitor");
        stage.show();
        close();
    }
}
