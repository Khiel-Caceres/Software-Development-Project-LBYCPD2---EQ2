package proj;
//DONE
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class RegisterPage implements Initializable
{
    ObservableList list = FXCollections.observableArrayList();
    @FXML
    public TextField email;
    public PasswordField password;
    public TextField contactNumber;
    public Button signUp;
    public Button goBack;
    public Button consentForm;
    public ChoiceBox<String> userType;
    public CheckBox check;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        pickUserType();
    }

    //gets details and shows error message if none of the details are filled
    public void getUserInfo()
    {
        String email = this.email.getText();
        String pass = password.getText();
        String num = this.contactNumber.getText();
        String type = userType.getValue();
        if (!(email.isEmpty() || (pass.isEmpty()) || (num.isEmpty()) || (type == null))) saveDetails();
        else
        {
            error1();
            setBlank();
        }
    }

    //objects for choiceBox
    public void pickUserType()
    {
        list.removeAll((list));
        String type1 = "PATIENT";
        String type2 = "NURSE";
        String type3 = "DOCTOR";
        String type4 = "ADMIN";
        list.addAll(type1, type2, type3, type4);
        userType.getItems().addAll(list);
    }

    //error if the text fields and choice box are left blank
    public void error1()
    {
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("ERROR!");
        window.setMinWidth(520);
        window.setMinHeight(150);
        Label message = new Label();
        message.setText("Please fill up all the details and/or select a user type");
        message.setFont(Font.font("Consolas", 16));
        message.setTextFill(Color.RED);
        VBox layout = new VBox(10);
        layout.getChildren().addAll(message);
        layout.setAlignment(Pos.CENTER);
        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();
    }

    //error if the user didn't check the check box
    public void error2()
    {
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("ERROR!");
        window.setMinWidth(520);
        window.setMinHeight(150);
        Label message = new Label();
        message.setText("You must agree with the terms and conditions to continue");
        message.setFont(Font.font("Consolas", 16));
        message.setTextFill(Color.RED);
        VBox layout = new VBox(10);
        layout.getChildren().addAll(message);
        layout.setAlignment(Pos.CENTER);
        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();
    }

    //message if registration went well
    public void success()
    {
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("SUCCESS!");
        window.setMinWidth(320);
        window.setMinHeight(150);
        Label message = new Label();
        message.setText("You are successfully registered");
        message.setFont(Font.font("Consolas", 16));
        message.setTextFill(Color.GREEN);
        VBox layout = new VBox(10);
        layout.getChildren().addAll(message);
        layout.setAlignment(Pos.CENTER);
        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();
    }

    //set the text fields to blank
    public void setBlank()
    {
        email.setText("");
        password.setText("");
        contactNumber.setText("");
    }

    //saves the details to a txt file (for now)
    //for example, all patient accounts in one text file
    public void saveDetails()
    {
        String email = this.email.getText();
        String pass = password.getText();
        String num = this.contactNumber.getText();
        String type = userType.getValue();
        if (check.isSelected())
        {
            try
            {
                appendToFile(email + "|" + pass + "|" + num + "|" + type + "\n");
                success();
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("LoginPage.fxml"));
                Parent parent = fxmlLoader.load();
                Stage stage = new Stage();
                stage.setScene(new Scene(parent));
                stage.show();
                close();
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
        }
        else error2();
    }

    private void appendToFile(String str)
    {
        try
        {
            // Open given file in append mode.
            BufferedWriter out = new BufferedWriter(new FileWriter("Accounts.txt", true));
            out.write(str);
            out.close();
        }
        catch (IOException e)
        {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    //close the register page
    public void close()
    {
        Stage stage = (Stage) signUp.getScene().getWindow();
        stage.close();
    }

    //go back to login page
    public void clickGoBack() throws IOException
    {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("LoginPage.fxml"));
        Parent parent = fxmlLoader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(parent));
        stage.setTitle("VMS: COVID-19 Monitor");
        stage.show();
        close();
    }

    public void clickConsentForm()
    {
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("DATA PRIVACY CONSENT FORM");
        window.setMinWidth(600);
        window.setMinHeight(320);
        Label message = new Label();
        message.setText(
                "The developers value the privacy and security of personal data entrusted to them by the users who will use the program.\n" +
                "They recognize their responsibilities under the Republic Act No. 10173 (Data Privacy Act of 2012), with respect\n" +
                "to the data they collect and record from the users of the program. The personal data obtained from the program\n" +
                "is stored in the database which is fully controlled by the developers and will only be accessed by authorized\n" +
                "personnel. Protection of the users' personal data is of utmost priority. With that in mind, I agree and\n" +
                "authorize the developers to:\n" +
                "\n" +
                "1. Use my personal data within reason and within the use of the program only such as for contacting purposes if needed.\n" +
                "\n" +
                "2. Retain my information during and after the use of the program, or until the time I write to the developers\n" +
                "to remove my personal information as soon as possible.\n" +
                "\n" +
                "In addition, I am also aware of the following:\n" +
                "\n" +
                "1. Access to the personal data is only limited to the developers and administrators of the program who are\n" +
                "also authorized by the developers.\n" +
                "\n" +
                "2. Improper use of the information in this program (online, offline, or printed) will be subject to\n" +
                "appropriate actions under the Data Privacy Act of 2012.\n" +
                "\n" +
                "Now, I understand and am assured that necessary precautions will be taken by the developers\n" +
                "to protect my personal information.");
        message.setFont(Font.font("Consolas",13));
        message.setTextFill(Color.BLACK);
        message.setAlignment(Pos.TOP_LEFT);
        message.setTextAlignment(TextAlignment.JUSTIFY);
        VBox layout = new VBox(20);
        layout.setStyle("-fx-background-color: #FCCACA");
        layout.getChildren().addAll(message);
        layout.setPadding(new Insets(20));
        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();
    }
}

