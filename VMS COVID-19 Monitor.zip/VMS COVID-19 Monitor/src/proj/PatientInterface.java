package proj;
//NOT DONE

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.*;
import java.net.URL;
import java.util.*;

public class PatientInterface implements Initializable
{
    ObservableList list = FXCollections.observableArrayList();
    public TextField name;
    public TextField city;
    public TextField age;
    public ChoiceBox<String> genderChoice;
    public ChoiceBox<String> symptomName;
    public Button results;
    public Button goBack;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle)
    {
        pickSymptom();
        pickGender();
    }

    public void pickSymptom()
    {
        list.removeAll((list));
        //NEGATIVE
        String type17 = "SYMPTOM IS NOT MENTIONED";
        //MILD
        String type1 = "DIZZINESS";
        String type2 = "DIARRHEA";
        String type3 = "SKIN RASHES";
        String type4 = "CONJUNCTIVITIS";
        String type5 = "SORE THROAT";
        String type6 = "NASAL CONGESTION";
        String type7 = "HEADACHE";
        String type8 = "LOSS OF TASTE";
        String type9 = "FATIGUE";
        String type10 = "DRY COUGH";
        String type11 = "FEVER";
        //SEVERE
        String type12 = "SHORTNESS OF BREATH";
        String type13 = "LOSS OF APPETITE";
        String type14 = "CONFUSION";
        String type15 = "CHEST PAIN";
        String type16 = "HIGH TEMPERATURE";
        list.addAll(type17, type1, type2, type3, type4, type5, type6, type7, type8, type9, type10, type11, type12, type13, type14, type15, type16);
        symptomName.getItems().addAll(list);
    }

    public void pickGender()
    {
        list.removeAll((list));
        String type1 = "MALE";
        String type2 = "FEMALE";
        list.addAll(type1, type2);
        genderChoice.getItems().addAll(list);
    }

    //gets details and shows error message if none of the details are filled
    public void clickCheckResults()
    {
        String name = this.name.getText();
        String city = this.city.getText();
        String age = this.age.getText();
        String gender = genderChoice.getValue();
        String symptom = symptomName.getValue();
        if (!(name.isEmpty() || (city.isEmpty()) || (age.isEmpty()) || (gender == null) || (symptom == null)))
        {
            savePatientInfo();
            checkResults();
        }
        else
        {
            error();
            setBlank();
        }
    }

    public void checkResults()
    {
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setMinWidth(600);
        window.setMinHeight(400);
        results.setOnAction(e -> {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/proj/GetResultsPage.fxml"));
            Parent root1 = null;
            try {
                root1 = fxmlLoader.load();
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
            Stage stage = new Stage();
            stage.setTitle("GET RESULTS");
            assert root1 != null;
            stage.setScene(new Scene(root1));
            stage.show();
            close();
        });
    }

    public void savePatientInfo()
    {
        String name = this.name.getText();
        String city = this.city.getText();
        String age = this.age.getText();
        String gender = genderChoice.getValue();
        String symptom = symptomName.getValue();
        appendStrToPatientDB(name + "|" + city + "|" + age + "|" + gender + "|" + symptom + "|" + createDecisionTree(symptom) + "\n");
    }

    private void appendStrToPatientDB(String str)
    {
        try
        {
            // Open given file in append mode.
            BufferedWriter out = new BufferedWriter(new FileWriter("PatientsDatabase.txt", true));
            out.write(str);
            out.close();
        }
        catch (IOException e)
        {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    String createDecisionTree(String symptom)
    {
        CheckSymptoms checker = new CheckSymptoms();
        checker.addNode(13,"SYMPTOMS");
        checker.addNode(14,"SEVERE");
        checker.addNode(15,"SHORTNESS OF BREATH"); //S-1
        checker.addNode(16,"LOSS OF APPETITE"); //S-2
        checker.addNode(17,"CONFUSION"); //S-3
        checker.addNode(18,"CHEST PAIN"); //S-4
        checker.addNode(19,"HIGH TEMPERATURE"); //S-5
        checker.addNode(12,"MILD");
        checker.addNode(11,"FEVER"); //M-11
        checker.addNode(10,"DRY COUGH"); //M-10
        checker.addNode(9,"FATIGUE"); //M-9
        checker.addNode(8,"LOSS OF TASTE"); //M-8
        checker.addNode(7,"HEADACHE"); //M-7
        checker.addNode(6,"NASAL CONGESTION"); //M-6
        checker.addNode(5,"CONJUNCTIVITIS"); //M-5
        checker.addNode(4,"MUSCLE PAIN"); //M-4
        checker.addNode(3,"SKIN RASHES"); //M-3
        checker.addNode(2,"DIARRHEA"); //M-2
        checker.addNode(1,"DIZZINESS"); //M-1

        for(int i = 1; i <= 19; i++)
        {
            String symptomTree = String.valueOf(checker.findNode(i));
            if(symptom.equals(symptomTree))
            {
                if(i > 14)
                {
                    return ("RESULT: Seek immediate medical attention");
                }
                return ("RESULT: Need to self-quarantine");
            }
        }
        return ("RESULT: Negative");
    }

    public void error()
    {
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("ERROR!");
        window.setMinWidth(600);
        window.setMinHeight(150);
        Label message = new Label();
        message.setText("Please fill up all the details needed before checking the results");
        message.setFont(Font.font("Consolas", 16));
        message.setTextFill(Color.RED);
        VBox layout = new VBox(10);
        layout.getChildren().addAll(message);
        layout.setAlignment(Pos.CENTER);
        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();
    }

    //set the text fields to blank
    public void setBlank()
    {
        name.setText("");
        city.setText("");
        age.setText("");
    }

    public void close()
    {
        Stage stage = (Stage) results.getScene().getWindow();
        stage.close();
    }

    public void clickGoBack() throws IOException
    {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("LoginPage.fxml"));
        Parent root1 = fxmlLoader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root1));
        stage.setTitle("VMS: COVID-19 Monitor");
        stage.show();
        close();
    }
}


