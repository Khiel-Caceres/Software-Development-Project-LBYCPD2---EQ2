package proj;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class AddPatient implements Initializable
{
    ObservableList list = FXCollections.observableArrayList();
    public TextField name;
    public TextField city;
    public TextField age;
    public ChoiceBox<String> genderChoice;
    public ChoiceBox<String> symptomName;
    public Button submit;
    public Button goBack;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle)
    {
        pickSymptom();
        pickGender();
    }

    public void pickSymptom()
    {
        list.removeAll((list));
        //NEGATIVE
        String type17 = "SYMPTOM IS NOT MENTIONED";
        //MILD
        String type1 = "DIZZINESS";
        String type2 = "DIARRHEA";
        String type3 = "SKIN RASHES";
        String type4 = "CONJUNCTIVITIS";
        String type5 = "SORE THROAT";
        String type6 = "NASAL CONGESTION";
        String type7 = "HEADACHE";
        String type8 = "LOSS OF TASTE";
        String type9 = "FATIGUE";
        String type10 = "DRY COUGH";
        String type11 = "FEVER";
        //SEVERE
        String type12 = "SHORTNESS OF BREATH";
        String type13 = "LOSS OF APPETITE";
        String type14 = "CONFUSION";
        String type15 = "CHEST PAIN";
        String type16 = "HIGH TEMPERATURE";
        list.addAll(type17, type1, type2, type3, type4, type5, type6, type7, type8, type9, type10, type11, type12, type13, type14, type15, type16);
        symptomName.getItems().addAll(list);
    }

    public void pickGender()
    {
        list.removeAll((list));
        String type1 = "MALE";
        String type2 = "FEMALE";
        list.addAll(type1, type2);
        genderChoice.getItems().addAll(list);
    }

    //gets details and shows error message if none of the details are filled
    public void clickSubmit() throws IOException
    {
        String name = this.name.getText();
        String city = this.city.getText();
        String age = this.age.getText();
        String gender = genderChoice.getValue();
        String symptom = symptomName.getValue();
        if (!(name.isEmpty() || (city.isEmpty()) || (age.isEmpty()) || (gender == null) || (symptom == null)))
        {
            savePatientInfo();
            success();
            clickGoBack();
        }
        else
        {
            error();
            setBlank();
        }
    }

    public void savePatientInfo()
    {
        String name = this.name.getText();
        String city = this.city.getText();
        String age = this.age.getText();
        String gender = genderChoice.getValue();
        String symptom = symptomName.getValue();
        appendStrToPatientDB(name + "|" + city + "|" + age + "|" + gender + "|" + symptom + "|" + createDecisionTree(symptom) + "\n");
    }

    private void appendStrToPatientDB(String str)
    {
        try
        {
            // Open given file in append mode.
            BufferedWriter out = new BufferedWriter(new FileWriter("PatientsDatabase.txt", true));
            out.write(str);
            out.close();
        }
        catch (IOException e)
        {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    String createDecisionTree(String symptom)
    {
        CheckSymptoms checker = new CheckSymptoms();
        checker.addNode(13,"SYMPTOMS");
        checker.addNode(14,"SEVERE");
        checker.addNode(15,"SHORTNESS OF BREATH"); //S-1
        checker.addNode(16,"LOSS OF APPETITE"); //S-2
        checker.addNode(17,"CONFUSION"); //S-3
        checker.addNode(18,"CHEST PAIN"); //S-4
        checker.addNode(19,"HIGH TEMPERATURE"); //S-5
        checker.addNode(12,"MILD");
        checker.addNode(11,"FEVER"); //M-11
        checker.addNode(10,"DRY COUGH"); //M-10
        checker.addNode(9,"FATIGUE"); //M-9
        checker.addNode(8,"LOSS OF TASTE"); //M-8
        checker.addNode(7,"HEADACHE"); //M-7
        checker.addNode(6,"NASAL CONGESTION"); //M-6
        checker.addNode(5,"CONJUNCTIVITIS"); //M-5
        checker.addNode(4,"MUSCLE PAIN"); //M-4
        checker.addNode(3,"SKIN RASHES"); //M-3
        checker.addNode(2,"DIARRHEA"); //M-2
        checker.addNode(1,"DIZZINESS"); //M-1

        for(int i = 1; i <= 19; i++)
        {
            String symptomTree = String.valueOf(checker.findNode(i));
            if(symptom.equals(symptomTree))
            {
                if(i > 14)
                {
                    return ("RESULT: Seek immediate medical attention");
                }
                return ("RESULT: Need to self-quarantine");
            }
        }
        return ("RESULT: Negative");
    }

    public void error()
    {
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("ERROR!");
        window.setMinWidth(600);
        window.setMinHeight(150);
        Label message = new Label();
        message.setText("Please fill up all the details needed before submitting");
        message.setFont(Font.font("Consolas", 16));
        message.setTextFill(Color.RED);
        VBox layout = new VBox(10);
        layout.getChildren().addAll(message);
        layout.setAlignment(Pos.CENTER);
        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();
    }

    public void success()
    {
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("SUCCESS!");
        window.setMinWidth(400);
        window.setMinHeight(150);
        Label message = new Label();
        message.setText("Patient has been added");
        message.setFont(Font.font("Consolas", 16));
        message.setTextFill(Color.GREEN);
        VBox layout = new VBox(10);
        layout.getChildren().addAll(message);
        layout.setAlignment(Pos.CENTER);
        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();
    }

    //set the text fields to blank
    public void setBlank()
    {
        name.setText("");
        city.setText("");
        age.setText("");
    }

    public void close()
    {
        Stage stage = (Stage) submit.getScene().getWindow();
        stage.close();
    }

    public void clickGoBack() throws IOException
    {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("NurseInterface.fxml"));
        Parent root1 = fxmlLoader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root1));
        stage.setTitle("NURSE");
        stage.show();
        close();
    }
}
