import java.io.*;
import java.util.*;

public class Main {

    Scanner input = new Scanner(System.in);

    void menu(){

        // Create a database
        try {
            File myObj = new File("PatientsDatabase.txt");
            if (myObj.createNewFile()) {
                System.out.println(">>>>>File created: " + myObj.getName() + "<<<<<");
            } else {
                System.out.println(">>>>>File already exists.<<<<<");
            }
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        int option=0;
        do{
            System.out.println("============MENU============");
            System.out.println("Patient Interface: ");
            System.out.println("[1] Input Information");
            System.out.println("[2] Show Results");
            System.out.println("============================");
            System.out.println("Nurse Interface: ");
            System.out.println("[3] Add Patient");
            System.out.println("[4] Delete Patient");
            System.out.println("[5] Edit Patient");
            System.out.println("[6] Search Patient");
            System.out.println("============================");
            System.out.println("Doctor Interface: ");
            System.out.println("[7] Show Patients");
            System.out.println("============================");
            System.out.println("Admin Interface: ");
            System.out.println("[8] Display Database");
            System.out.println("[9] Exit");
            System.out.println(">>> ");
            option = input.nextInt();
            switch (option) {
                case 1:
                    inputInformation();
                    break;
                case 2:
                    showResults();
                    break;
                case 3:
                    addPatient();
                    break;
                case 4:
                    deletePatient();
                    break;
                case 5:
                    editPatient();
                    break;
                case 6:
                    searchPatient();
                    break;
                case 7:
                    showPatients();
                    break;
                case 8:
                    displayDatabase();
                    break;
                case 9:
                    System.out.println("Have a nice day.");
                    break;
                default:
                    System.out.println("Invalid Input");
            }
        } while (option!=9);
    }

    private void inputInformation() {
        input.nextLine();
        System.out.println("Enter Name: ");
        String name = input.nextLine();
        System.out.println("Enter Age: ");
        String age = input.nextLine();
        System.out.println("Enter City");
        String city = input.nextLine();
        System.out.println("Enter Gender: ");
        String gender = input.nextLine();
        System.out.println("Enter symptom: ");
        String symptom = input.nextLine();
        appendStrToPatient(name+" "+age+" "+city+" "+gender+" "+symptom+" "+createDecisionTree(symptom)+"\n");
    }

    private void showResults() {
        input.nextLine();
        System.out.println("Enter Name: ");
        String name = input.nextLine();

        boolean bool=false;
        try {
            File myObj = new File("PatientsDatabase.txt");
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                if(data.contains(name)){
                    System.out.println(data);
                    bool=true;
                    break;
                }
                else{
                    continue;
                }
            }
            if(!bool==true){
                System.out.println("Patient not found.");
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    private void addPatient() {
        input.nextLine();
        System.out.println("Enter Name: ");
        String name = input.nextLine();
        System.out.println("Enter Age: ");
        String age = input.nextLine();
        System.out.println("Enter City");
        String city = input.nextLine();
        System.out.println("Enter Gender: ");
        String gender = input.nextLine();
        System.out.println("Enter symptom: ");
        String symptom = input.nextLine();
        appendStrToPatient(name+" "+age+" "+city+" "+gender+" "+symptom+" "+createDecisionTree(symptom)+"\n");
    }

    private void deletePatient() {

        input.nextLine();
        System.out.println("Enter patient's name: ");
        String name = input.nextLine();

        String database="";
        // Read database
        try {
            File myObj = new File("PatientsDatabase.txt");
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                if(data.contains(name)){
                    continue;
                }
                else{
                    database+=data;
                }
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        // Delete previous database
        File myObj = new File("PatientsDatabase.txt");
        myObj.delete();

        // Create a new database
        try {
            File myObj1 = new File("PatientsDatabase.txt");
            myObj1.createNewFile();
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        appendStrToPatient(database);

    }

    private void editPatient() {

        input.nextLine();
        System.out.println("Enter patient's name: ");
        String name = input.nextLine();

        String database="";
        // Read database
        try {
            File myObj = new File("PatientsDatabase.txt");
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                if(data.contains(name)){
                    System.out.println("Enter Name: ");
                    String name2 = input.nextLine();
                    System.out.println("Enter Age: ");
                    String age = input.nextLine();
                    System.out.println("Enter City");
                    String city = input.nextLine();
                    System.out.println("Enter Gender: ");
                    String gender = input.nextLine();
                    System.out.println("Enter symptom: ");
                    String symptom = input.nextLine();
                    database+=(name2+" "+age+" "+city+" "+gender+" "+symptom+" "+createDecisionTree(symptom)+"\n");
                }
                else{
                    database+=(data+"\n");
                }
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        // Delete previous database
        File myObj = new File("PatientsDatabase.txt");
        myObj.delete();

        // Create a new database
        try {
            File myObj1 = new File("PatientsDatabase.txt");
            myObj1.createNewFile();
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        appendStrToPatient(database);
    }

    private void searchPatient() {
        input.nextLine();
        System.out.println("Enter Name: ");
        String name = input.nextLine();

        boolean bool=false;
        try {
            File myObj = new File("PatientsDatabase.txt");
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                if(data.contains(name)){
                    System.out.println(data);
                    bool=true;
                    break;
                }
                else{
                    continue;
                }
            }
            if(!bool==true){
                System.out.println("Patient not found.");
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    private void showPatients() {
        input.nextLine();
        System.out.println("Enter City: ");
        String city = input.nextLine();

        String datas = "";
        boolean bool = false;
        try {
            File myObj = new File("PatientsDatabase.txt");
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                if(data.contains(city)){
                    datas+=(data+"\n");
                    bool=true;
                    break;
                }
                else{
                    continue;
                }
            }
            System.out.println(datas);
            if(!bool==true){
                System.out.println("No patients found.");
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    private void displayDatabase() {
        try {
            File myObj = new File("PatientsDatabase.txt");
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                System.out.println(data);
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    private void appendStrToPatient(String str) {
        try {

            // Open given file in append mode.
            BufferedWriter out = new BufferedWriter(
                    new FileWriter("PatientsDatabase.txt", true));
            out.write(str);
            out.close();
        }
        catch (IOException e) {
            System.out.println("exception occoured" + e);
        }
    }

    String createDecisionTree(String symptom){

        SymptomsChecker tree = new SymptomsChecker();
        tree.addNode(13,"SYMPTOMS");
        tree.addNode(14,"SEVERE");
        tree.addNode(15,"SHORTNESS OF BREATH");
        tree.addNode(16,"LOSS OF APPETITE");
        tree.addNode(17,"CONFUSION");
        tree.addNode(18,"CHEST PAIN");
        tree.addNode(19,"HIGH TEMPERATURE");
        tree.addNode(12,"MILD");
        tree.addNode(11,"FEVER");
        tree.addNode(10,"DRY COUGH");
        tree.addNode(9,"FATIGUE");
        tree.addNode(8,"LOSS OF TASTE");
        tree.addNode(7,"HEADACHE");
        tree.addNode(6,"NASAL CONGESTION");
        tree.addNode(5,"CONJUNCTIVITIS");
        tree.addNode(4,"MUSCLE PAIN");
        tree.addNode(3,"SKIN RASHES");
        tree.addNode(2,"DIARRHEA");
        tree.addNode(1,"DIZZINESS");

        for(int i=1;i<=19;i++){
            String symptomTree = String.valueOf(tree.findNode(i));
            if(symptom.equals(symptomTree)){
                if(i>14){
                    return ("Seek immediate medical attention");
                }
                return ("Need to self-quarantine");
            }

        }
        return ("Negative");

    }
    public static void main(String[] args){
        Main x = new Main();
        x.menu();
    }
}
