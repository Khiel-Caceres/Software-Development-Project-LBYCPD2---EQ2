import java.io.File;
import java.util.*;

public class Main {
    HashMap<String, LinkedList<String>> patients = new HashMap<>();
    Stack<String> negative = new Stack<String>();
    Stack<String> mild = new Stack<String>();
    Stack<String> severe = new Stack<String>();

    Scanner input = new Scanner(System.in);

    Scanner x;
    String inputEmail;
    String inputPassword;

    void menu(){
        //Login
        System.out.println("=========Welcome===========");
        System.out.print("Please Enter your email: ");
        inputEmail = input.nextLine();
        System.out.print("Please enter your password: ");
        inputPassword = input.nextLine();

        //Account File
        opeFile();
        readFile();
        closeFile();

        int option=0;
        do{
            System.out.println("============MENU============");
            System.out.println("[1] Add Patient");
            System.out.println("[2] Delete Patient");
            System.out.println("[3] Search Patient");
            System.out.println("[4] See all patients");
            System.out.println("[5] See all results");
            System.out.println("[6] Exit");
            System.out.println(">>> ");
            option = input.nextInt();
            switch (option) {
                case 1:
                    inputPatient();
                    break;
                case 2:
                    System.out.println(deletePatient());
                    break;
                case 3:
                    System.out.println(searchPatient());
                    break;
                case 4:
                    seeAllPatients();
                    break;
                case 5:
                    seeAllResults();
                    break;
                case 6:
                    System.out.println("Have a nice day.");
                    break;
                default:
                    System.out.println("Invalid Input");
            }
        } while (option!=6);
    }

    void inputPatient(){

        String secondStack = "Need to self-quarantine";
        String thirdStack = "Seek immediate medical attention";

        input.nextLine();
        System.out.println("Enter name of patient: ");
        String name = input.nextLine().toUpperCase(Locale.ROOT);
        System.out.println("Enter age: ");
        String age = input.nextLine();
        System.out.println("Enter city came from: ");
        String city = input.nextLine();
        System.out.println("Enter symptom: ");
        String symptom = input.nextLine().toUpperCase();

        String decisionTreeOutput = createDecisionTree(symptom);
        if(secondStack.equals(decisionTreeOutput)){
            mild.add(name);
        }
        else if(thirdStack.equals(decisionTreeOutput)){
            severe.add(name);
        }
        else{
            negative.add(name);
        }

        if(!patients.containsKey(name)){
            LinkedList<String> patient= new LinkedList<>();
            patient.add(age);
            patient.add(city);
            patient.add(symptom);
            patient.add(decisionTreeOutput);
            patients.put(name,patient);
        }

        else{
            LinkedList<String> patient= patients.get(name);
            patient.add(age);
            patient.add(city);
            patient.add(symptom);
            patient.add(decisionTreeOutput);
            patients.put(name,patient);
        }

    }

    String deletePatient(){

        input.nextLine();
        System.out.println("Enter name of patient: ");
        String name = input.nextLine().toUpperCase(Locale.ROOT);

        for (Map.Entry m : patients.entrySet()) {
            if(name.equals(m.getKey())){
                patients.remove(m.getKey());
                return ("Patient deleted.");
            }
        }
        return ("Patient not found.");
    }

    String searchPatient(){

        input.nextLine();
        System.out.println("Enter name of patient: ");
        String name = input.nextLine().toUpperCase(Locale.ROOT);

        for (Map.Entry m : patients.entrySet()) {
            if(name.equals(m.getKey())){
                return (m.getKey()+" ==> "+m.getValue());
            }
        }
        return ("Patient not found.");
    }

    void seeAllPatients(){
        for (Map.Entry m : patients.entrySet()) {
            System.out.println(m.getKey() + " ==> " + m.getValue());
        }
    }

    void seeAllResults(){
        System.out.println("==================================");
        System.out.println("Negative: ");
        while(!negative.isEmpty()){
            System.out.println(negative.pop());
        }
        System.out.println("==================================");
        System.out.println("Need to self-quarantine: ");
        while(!mild.isEmpty()){
            System.out.println(mild.pop());
        }
        System.out.println("==================================");
        System.out.println("Seek immediate medical attention: ");
        while(!severe.isEmpty()){
            System.out.println(severe.pop());
        }
        System.out.println("==================================");
    }

    String createDecisionTree(String symptom){

        SymptomsChecker tree = new SymptomsChecker();
        tree.addNode(13,"SYMPTOMS");
        tree.addNode(14,"SEVERE");
        tree.addNode(15,"SHORTNESS OF BREATH");
        tree.addNode(16,"LOSS OF APPETITE");
        tree.addNode(17,"CONFUSION");
        tree.addNode(18,"CHEST PAIN");
        tree.addNode(19,"HIGH TEMPERATURE");
        tree.addNode(12,"MILD");
        tree.addNode(11,"FEVER");
        tree.addNode(10,"DRY COUGH");
        tree.addNode(9,"FATIGUE");
        tree.addNode(8,"LOSS OF TASTE");
        tree.addNode(7,"HEADACHE");
        tree.addNode(6,"NASAL CONGESTION");
        tree.addNode(5,"CONJUNCTIVITIS");
        tree.addNode(4,"MUSCLE PAIN");
        tree.addNode(3,"SKIN RASHES");
        tree.addNode(2,"DIARRHEA");
        tree.addNode(1,"DIZZINESS");

        for(int i=1;i<=19;i++){
            String symptomTree = String.valueOf(tree.findNode(i));
            if(symptom.equals(symptomTree)){
                if(i>14){
                    return ("Seek immediate medical attention");
                }
                return ("Need to self-quarantine");
            }

        }
        return ("Negative");

    }
    public static void main(String[] args){
        Main x = new Main();
        x.menu();
    }

    public void opeFile() {
        try {
            x = new Scanner(new File("C:\\Users\\User\\Desktop\\Project\\src\\assets\\accounts"));
        }
        catch (Exception e) {
            System.out.println("could not find file");
        }
    }

    public void readFile() {
        String email = x.next();
        String password = x.next();

        while(x.hasNext() && !email.equals(inputEmail) && !password.equals(inputPassword)) {
            email = x.next();
            password = x.next();
        }

        System.out.println(email);
        System.out.println(password);

        if (email.equals(inputEmail) && password.equals(inputPassword)) {
            System.out.println("\n=======================================");
            System.out.println("Your account details is in the database");
            System.out.println("=======================================");
        }

        else {
            System.out.println("\n=========================================");
            System.out.println("Wrong email or password, Please try again");
            System.out.println("=========================================");
            System.exit(0);
        }
    }

    public void closeFile() {
        x.close();
    }
}
