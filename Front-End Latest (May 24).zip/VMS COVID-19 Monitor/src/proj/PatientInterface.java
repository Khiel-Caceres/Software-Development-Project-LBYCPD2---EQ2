package proj;
//NOT DONE

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.*;
import java.net.URL;
import java.util.*;

public class PatientInterface implements Initializable
{
    ObservableList list = FXCollections.observableArrayList();
    public TextField name;
    public TextField city;
    public TextField age;
    public ChoiceBox<String> genderChoice;
    public ChoiceBox<String> symptomName;
    public Button showResults;
    public Button goBack;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle)
    {
        pickSymptom();
        pickGender();
    }

    public void pickSymptom()
    {
        list.removeAll((list));
        //MOST COMMON
        String type1 = "FEVER";
        String type2 = "DRY COUGH";
        String type3 = "TIREDNESS";
        //LESS COMMON
        String type4 = "ACHES AND PAINS";
        String type5 = "SORE THROAT";
        String type6 = "DIARRHEA";
        String type7 = "CONJUNCTIVITIS";
        String type8 = "HEADACHE";
        String type9 = "LOSS OF TASTE/SMELL";
        String type10 = "RASH ON SKIN";
        String type11 = "FINGERS/TOES DISCOLORATION";
        //SERIOUS
        String type12 = "SHORTNESS OF BREATH";
        String type13 = "CHEST PAIN/PRESSURE";
        String type14 = "LOSS OF SPEECH/MOVEMENT";
        list.addAll(type1, type2, type3, type4, type5, type6, type7, type8, type9, type10, type11, type12, type13, type14);
        symptomName.getItems().addAll(list);
    }

    public void pickGender()
    {
        list.removeAll((list));
        String type1 = "MALE";
        String type2 = "FEMALE";
        list.addAll(type1, type2);
        genderChoice.getItems().addAll(list);
    }

    public String getSymptom(ChoiceBox<String> choice)
    {
        String type = choice.getValue();
        System.out.println("The symptom chosen is " + type);
        return type;
    }

    public String getGender(ChoiceBox<String> choice)
    {
        String type = choice.getValue();
        System.out.println("The gender chosen is " + type);
        return type;
    }

    //put codes to make it show the results (base it off on old proj)
    //gets details and shows error message if none of the details are filled
    public void clickShowResults() throws IOException
    {
        String name = this.name.getText();
        String city = this.city.getText();
        String age = this.age.getText();
        String gender = genderChoice.getValue();
        String symptom = symptomName.getValue();
        if (!(name.isEmpty() || (city.isEmpty()) || (age.isEmpty()) || (gender == null) || (symptom == null)))
        {
            savePatientInfo();
            displayResults();
        }
        else
        {
            error();
            setBlank();
        }

    }

    public void savePatientInfo()
    {
        String name = this.name.getText();
        String city = this.city.getText();
        String age = this.age.getText();
        File myObj = new File("Patient Database.txt");
        try {
            if (myObj.createNewFile()) {
                File file = new File("Patient Database.txt");
                FileWriter fr = new FileWriter(file, true);
                BufferedWriter br = new BufferedWriter(fr);
                for (int i = 1; i < 5; i++) //for each variable use something like a hashmap or linked list data structure if ever
                {
                    br.write("Patient " + i + ":");
                    br.newLine();
                    br.write(name);
                    br.newLine();
                    br.write(city);
                    br.newLine();
                    br.write(age);
                    br.newLine();
                    br.write(getGender(genderChoice));
                    br.newLine();
                    br.write(getSymptom(symptomName));
                    br.newLine();
                    br.newLine();
                }
                br.close();
                fr.close();
            }
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        success();
    }

    public void displayResults() throws IOException
    {
        BufferedReader br = new BufferedReader(new FileReader("Patient Database.txt"));
        String line;
        while((line = br.readLine()) != null)
        {
            System.out.println(line); //for checking only if it reads the file properly
        }
        br.close();
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("RESULTS");
        window.setMinWidth(400);
        window.setMinHeight(150);
        Label message = new Label();
        message.setText("RESULTS WILL COME FROM THE DATABASE"); //temporary message for button
        message.setFont(Font.font("Consolas", 16));
        message.setTextFill(Color.BLACK);
        VBox layout = new VBox(10);
        layout.getChildren().addAll(message);
        layout.setAlignment(Pos.CENTER);
        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();
    }

    public void error()
    {
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("ERROR!");
        window.setMinWidth(600);
        window.setMinHeight(150);
        Label message = new Label();
        message.setText("Please fill up all the details needed before showing the results");
        message.setFont(Font.font("Consolas", 16));
        message.setTextFill(Color.RED);
        VBox layout = new VBox(10);
        layout.getChildren().addAll(message);
        layout.setAlignment(Pos.CENTER);
        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();
    }

    public void success()
    {
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("SUCCESS!");
        window.setMinWidth(400);
        window.setMinHeight(150);
        Label message = new Label();
        message.setText("That patient is saved to the database");
        message.setFont(Font.font("Consolas", 16));
        message.setTextFill(Color.GREEN);
        VBox layout = new VBox(10);
        layout.getChildren().addAll(message);
        layout.setAlignment(Pos.CENTER);
        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();
    }

    //set the text fields to blank
    public void setBlank()
    {
        name.setText("");
        city.setText("");
        age.setText("");
    }

    public void close()
    {
        Stage stage = (Stage) showResults.getScene().getWindow();
        stage.close();
    }

    public void clickGoBack() throws IOException
    {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("LoginPage.fxml"));
        Parent root1 = fxmlLoader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root1));
        stage.show();
        close();
    }
}


