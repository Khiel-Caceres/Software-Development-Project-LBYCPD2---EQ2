package proj;
//NOT DONE
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class DoctorInterface implements Initializable
{
    ObservableList list = FXCollections.observableArrayList();
    public Button showAll;
    public Button goBack;
    public TextField city;
    public ChoiceBox<String> patientType;

    public void pickPatientType()
    {
        list.removeAll((list));
        String type1 = "NEGATIVE PATIENTS";
        String type2 = "SELF-QUARANTINED PATIENTS";
        String type3 = "PATIENTS WHO NEED MEDICAL ATTENTION";
        list.addAll(type1, type2, type3);
        patientType.getItems().addAll(list);
    }

    public void getPatientType(ChoiceBox<String> choice)
    {
        String type = choice.getValue();
        System.out.println("The patient type chosen is " + type);
    }

    public void clickShowAllPatients()
    {
        String city = this.city.getText();
        String pType = patientType.getValue();
        if (!((city.isEmpty()) || (pType == null)))
        {
            getPatientType(patientType);
            displayAllPatients();
        }
        else
        {
            error();
            this.city.setText("");
        }
    }

    public void displayAllPatients()
    {
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("PATIENT TYPE");
        window.setMinWidth(500);
        window.setMinHeight(150);
        Label message = new Label();
        message.setText("PATIENT TYPE WILL COME FROM THE DATABASE"); //temporary message for button
        message.setFont(Font.font("Consolas", 16));
        message.setTextFill(Color.BLACK);
        VBox layout = new VBox(10);
        layout.getChildren().addAll(message);
        layout.setAlignment(Pos.CENTER);
        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();
    }

    public void error()
    {
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("ERROR!");
        window.setMinWidth(700);
        window.setMinHeight(150);
        Label message = new Label();
        message.setText("Please fill up all the details needed before showing the type of patients");
        message.setFont(Font.font("Consolas", 16));
        message.setTextFill(Color.RED);
        VBox layout = new VBox(10);
        layout.getChildren().addAll(message);
        layout.setAlignment(Pos.CENTER);
        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();
    }

    public void close()
    {
        Stage stage = (Stage) showAll.getScene().getWindow();
        stage.close();
    }

    public void clickGoBack() throws IOException
    {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("LoginPage.fxml"));
        Parent root1 = fxmlLoader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root1));
        stage.show();
        close();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle)
    {
        pickPatientType();
    }
}
