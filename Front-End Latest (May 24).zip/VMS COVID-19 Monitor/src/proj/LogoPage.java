package proj;
//DONE
import javafx.animation.FadeTransition;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.ResourceBundle;

public class LogoPage implements Initializable
{
    public AnchorPane anchor;

    public void fadeOutEffect()
    {
        FadeTransition fadeTransition = new FadeTransition();
        fadeTransition.setDuration(Duration.millis(5000));
        fadeTransition.setNode(anchor);
        fadeTransition.setFromValue(1);
        fadeTransition.setToValue(0);

        fadeTransition.setOnFinished(actionEvent -> {
            try {
                loadLogin();
            } catch (IOException exception) {
                exception.printStackTrace();
            }
        });
        fadeTransition.play();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        fadeOutEffect();
    }

    public void loadLogin() throws IOException
    {
        try
        {
            Parent secondPage = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("LoginPage.fxml")));
            Scene scene = new Scene(secondPage);
            Stage currentStage  = (Stage) anchor.getScene().getWindow();
            currentStage.setTitle("LOGIN");
            currentStage.setMinWidth(1000);
            currentStage.setMinHeight(700);
            currentStage.setScene(scene);
        } catch (IOException ex){
            ex.printStackTrace();
        }
    }
}
