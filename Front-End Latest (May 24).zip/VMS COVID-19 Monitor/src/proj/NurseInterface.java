package proj;
//NOT DONE
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class NurseInterface implements Initializable {

    public Button add;
    public Button del;
    public Button edit;
    public Button search;
    public Button goBack;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle)
    {

    }

    public void clickAddPatient()
    {
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("ADD PATIENT");
        window.setMinWidth(400);
        window.setMinHeight(150);
        Label message = new Label();
        message.setText("PATIENT ADDED IN THE DATABASE"); //temporary message for button
        message.setFont(Font.font("Consolas", 16));
        message.setTextFill(Color.BLACK);
        VBox layout = new VBox(10);
        layout.getChildren().addAll(message);
        layout.setAlignment(Pos.CENTER);
        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();
    }

    public void clickDeletePatient()
    {
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("DELETE PATIENT");
        window.setMinWidth(400);
        window.setMinHeight(150);
        Label message = new Label();
        message.setText("PATIENT DELETED FROM THE DATABASE"); //temporary message for button
        message.setFont(Font.font("Consolas", 16));
        message.setTextFill(Color.BLACK);
        VBox layout = new VBox(10);
        layout.getChildren().addAll(message);
        layout.setAlignment(Pos.CENTER);
        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();
    }

    public void clickEditPatient()
    {
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("EDIT PATIENT");
        window.setMinWidth(400);
        window.setMinHeight(150);
        Label message = new Label();
        message.setText("PATIENT EDITED IN THE DATABASE"); //temporary message for button
        message.setFont(Font.font("Consolas", 16));
        message.setTextFill(Color.BLACK);
        VBox layout = new VBox(10);
        layout.getChildren().addAll(message);
        layout.setAlignment(Pos.CENTER);
        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();
    }

    public void clickSearchPatient()
    {
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("SEARCH PATIENT");
        window.setMinWidth(400);
        window.setMinHeight(150);
        Label message = new Label();
        message.setText("PATIENT SEARCHED IN THE DATABASE"); //temporary message for button
        message.setFont(Font.font("Consolas", 16));
        message.setTextFill(Color.BLACK);
        VBox layout = new VBox(10);
        layout.getChildren().addAll(message);
        layout.setAlignment(Pos.CENTER);
        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();
    }

    public void close()
    {
        Stage stage = (Stage) add.getScene().getWindow();
        stage.close();
    }

    public void clickGoBack() throws IOException
    {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("LoginPage.fxml"));
        Parent root1 = fxmlLoader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root1));
        stage.show();
        close();
    }
}
